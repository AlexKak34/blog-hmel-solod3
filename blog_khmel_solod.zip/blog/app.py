import os
from datetime import datetime

from flask import (Flask, render_template, request, redirect,
                   url_for, flash, login_required)
from flask_sqlalchemy import SQLAlchemy
from flask_login import (LoginManager, UserMixin, login_user,
                         logout_user, current_user)
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'change-me-in-production')
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///blog.db'
db = SQLAlchemy(app)

login_manager = LoginManager(app)
login_manager.login_view = 'login'

# ---------- модели ----------

post_tags = db.Table('post_tags',
    db.Column('post_id', db.Integer, db.ForeignKey('post.id'), primary_key=True),
    db.Column('tag_id', db.Integer, db.ForeignKey('tag.id'), primary_key=True))

subscriptions = db.Table('subscriptions',
    db.Column('subscriber_id', db.Integer, db.ForeignKey('user.id'), primary_key=True),
    db.Column('subscribed_id', db.Integer, db.ForeignKey('user.id'), primary_key=True))

post_access = db.Table('post_access',
    db.Column('post_id', db.Integer, db.ForeignKey('post.id'), primary_key=True),
    db.Column('user_id', db.Integer, db.ForeignKey('user.id'), primary_key=True))

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    posts = db.relationship('Post', backref='author', lazy=True)
    comments = db.relationship('Comment', backref='author', lazy=True)
    subscriptions = db.relationship('User', secondary=subscriptions,
        primaryjoin=(subscriptions.c.subscriber_id == id),
        secondaryjoin=(subscriptions.c.subscribed_id == id),
        backref='followers')

    def set_password(self, raw):
        self.password_hash = generate_password_hash(raw)

    def check_password(self, raw):
        return check_password_hash(self.password_hash, raw)

class Tag(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), unique=True, nullable=False)

class Post(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    body = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    author_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    visibility = db.Column(db.String(10), default='public')  # public | request | private
    tags = db.relationship('Tag', secondary=post_tags, backref='posts')
    comments = db.relationship('Comment', backref='post',
                               lazy=True, cascade='all, delete-orphan')
    allowed_users = db.relationship('User', secondary=post_access, backref='granted_posts')
    access_requests = db.relationship('AccessRequest', backref='post',
                                      lazy=True, cascade='all, delete-orphan')

class Comment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    body = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    author_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    post_id = db.Column(db.Integer, db.ForeignKey('post.id'), nullable=False)

class AccessRequest(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    post_id = db.Column(db.Integer, db.ForeignKey('post.id'), nullable=False)
    requester_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    status = db.Column(db.String(10), default='pending')  # pending | approved | declined
    requester = db.relationship('User')

    __table_args__ = (db.UniqueConstraint('post_id', 'requester_id'),)

@login_manager.user_loader
def load_user(user_id):
    return db.session.get(User, int(user_id))

VIS_LABELS = {'public': 'публичный', 'request': 'по запросу', 'private': 'личный'}

# ---------- вспомогательные функции ----------

def can_view(post, user):
    if post.visibility == 'public':
        return True
    if not user.is_authenticated:
        return False
    if post.author_id == user.id:
        return True
    return user in post.allowed_users

def get_or_create_tags(raw):
    names = [t.strip().lower() for t in raw.split(',') if t.strip()][:10]
    tags = []
    for n in names:
        tag = Tag.query.filter_by(name=n).first()
        if not tag:
            tag = Tag(name=n)
            db.session.add(tag)
        tags.append(tag)
    return tags

def filter_and_sort(posts):
    tag = request.args.get('tag', '').strip().lower()
    sort = request.args.get('sort', 'new')
    if tag:
        posts = [p for p in posts if any(t.name == tag for t in p.tags)]
    if sort == 'popular':
        posts.sort(key=lambda p: len(p.comments), reverse=True)
    else:
        posts.sort(key=lambda p: p.created_at, reverse=True)
    return posts

# ---------- маршруты ----------

@app.route('/')
def feed():
    if current_user.is_authenticated:
        followed_ids = [u.id for u in current_user.subscriptions] + [current_user.id]
        posts = [p for p in Post.query.filter(Post.author_id.in_(followed_ids))
                 if can_view(p, current_user)]
    else:
        posts = Post.query.filter_by(visibility='public').all()
    return render_template('feed.html', posts=filter_and_sort(posts),
                           tag=request.args.get('tag', ''),
                           sort=request.args.get('sort', 'new'),
                           title='Лента')

@app.route('/public')
def public_posts():
    posts = Post.query.filter_by(visibility='public').all()
    return render_template('feed.html', posts=filter_and_sort(posts),
                           tag=request.args.get('tag', ''),
                           sort=request.args.get('sort', 'new'),
                           title='Публичные посты')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('feed'))
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')
        if len(username) < 3 or len(password) < 6:
            flash('Имя — минимум 3 символа, пароль — минимум 6.')
            return render_template('register.html')
        if User.query.filter_by(username=username).first():
            flash('Это имя уже занято.')
            return render_template('register.html')
        user = User(username=username)
        user.set_password(password)
        db.session.add(user)
        db.session.commit()
        login_user(user)
        flash('Регистрация прошла успешно!')
        return redirect(url_for('feed'))
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('feed'))
    if request.method == 'POST':
        user = User.query.filter_by(
            username=request.form.get('username', '').strip()).first()
        if user and user.check_password(request.form.get('password', '')):
            login_user(user)
            return redirect(url_for('feed'))
        flash('Неверное имя или пароль.')
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('feed'))

@app.route('/post/new', methods=['GET', 'POST'])
@login_required
def new_post():
    if request.method == 'POST':
        post = Post(title=request.form.get('title', '').strip(),
                    body=request.form.get('body', ''),
                    author_id=current_user.id,
                    visibility=request.form.get('visibility', 'public'))
        post.tags = get_or_create_tags(request.form.get('tags', ''))
        db.session.add(post)
        db.session.commit()
        flash('Пост опубликован!')
        return redirect(url_for('post_view', post_id=post.id))
    return render_template('post_form.html', post=None, tags_str='')

@app.route('/post/<int:post_id>')
def post_view(post_id):
    post = db.get_or_404(Post, post_id)
    allowed = can_view(post, current_user)
    my_request = None
    if current_user.is_authenticated:
        my_request = AccessRequest.query.filter_by(
            post_id=post.id, requester_id=current_user.id).first()
    return render_template('post_view.html', post=post, allowed=allowed,
                           my_request=my_request, vis_labels=VIS_LABELS)

@app.route('/post/<int:post_id>/edit', methods=['GET', 'POST'])
@login_required
def edit_post(post_id):
    post = db.get_or_404(Post, post_id)
    if post.author_id != current_user.id:
        flash('Редактировать можно только свои посты.')
        return redirect(url_for('post_view', post_id=post.id))
    if request.method == 'POST':
        post.title = request.form.get('title', '').strip()
        post.body = request.form.get('body', '')
        post.visibility = request.form.get('visibility', 'public')
        post.tags = get_or_create_tags(request.form.get('tags', ''))
        db.session.commit()
        flash('Пост обновлён.')
        return redirect(url_for('post_view', post_id=post.id))
    return render_template('post_form.html', post=post,
                           tags_str=', '.join(t.name for t in post.tags))

@app.route('/post/<int:post_id>/delete', methods=['POST'])
@login_required
def delete_post(post_id):
    post = db.get_or_404(Post, post_id)
    if post.author_id != current_user.id:
        flash('Удалять можно только свои посты.')
        return redirect(url_for('feed'))
    db.session.delete(post)
    db.session.commit()
    flash('Пост удалён.')
    return redirect(url_for('feed'))

@app.route('/post/<int:post_id>/comment', methods=['POST'])
@login_required
def add_comment(post_id):
    post = db.get_or_404(Post, post_id)
    if not can_view(post, current_user):
        flash('Нет доступа к этому посту.')
        return redirect(url_for('feed'))
    body = request.form.get('body', '').strip()
    if body:
        db.session.add(Comment(body=body, author_id=current_user.id, post_id=post.id))
        db.session.commit()
    return redirect(url_for('post_view', post_id=post.id))

@app.route('/post/<int:post_id>/request-access', methods=['POST'])
@login_required
def request_access(post_id):
    post = db.get_or_404(Post, post_id)
    if post.visibility != 'request':
        return redirect(url_for('post_view', post_id=post.id))
    existing = AccessRequest.query.filter_by(
        post_id=post.id, requester_id=current_user.id).first()
    if existing and existing.status == 'pending':
        flash('Заявка уже отправлена — ждите решения автора.')
    elif existing:
        existing.status = 'pending'
        db.session.commit()
        flash('Заявка отправлена повторно.')
    else:
        db.session.add(AccessRequest(post_id=post.id, requester_id=current_user.id))
        db.session.commit()
        flash('Заявка на доступ отправлена.')
    return redirect(url_for('post_view', post_id=post.id))

@app.route('/requests')
@login_required
def requests_page():
    reqs = AccessRequest.query.filter_by(status='pending').all()
    mine = [r for r in reqs if r.post.author_id == current_user.id]
    return render_template('requests.html', requests=mine)

@app.route('/requests/<int:req_id>/<decision>', methods=['POST'])
@login_required
def handle_request(req_id, decision):
    req = db.get_or_404(AccessRequest, req_id)
    if req.post.author_id != current_user.id:
        flash('Это не ваша заявка.')
        return redirect(url_for('requests_page'))
    if decision == 'approve':
        req.status = 'approved'
        req.post.allowed_users.append(req.requester)
        flash('Доступ разрешён.')
    else:
        req.status = 'declined'
        flash('Заявка отклонена.')
    db.session.commit()
    return redirect(url_for('requests_page'))

@app.route('/users')
def users_list():
    users = User.query.order_by(User.username).all()
    subscribed_ids = {u.id for u in current_user.subscriptions} \
        if current_user.is_authenticated else set()
    return render_template('users.html', users=users, subscribed_ids=subscribed_ids)

@app.route('/user/<int:user_id>/subscribe', methods=['POST'])
@login_required
def subscribe(user_id):
    user = db.get_or_404(User, user_id)
    if user.id != current_user.id and user not in current_user.subscriptions:
        current_user.subscriptions.append(user)
        db.session.commit()
        flash(f'Вы подписались на {user.username}.')
    return redirect(request.referrer or url_for('users_list'))

@app.route('/user/<int:user_id>/unsubscribe', methods=['POST'])
@login_required
def unsubscribe(user_id):
    user = db.get_or_404(User, user_id)
    if user in current_user.subscriptions:
        current_user.subscriptions.remove(user)
        db.session.commit()
        flash(f'Вы отписались от {user.username}.')
    return redirect(request.referrer or url_for('users_list'))

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)
